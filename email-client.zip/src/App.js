import React, { Component } from 'react';
import ImageFileSender from './components/ImageFileSender';
import './App.css';
class App extends Component {
  render() {
    return (

   <ImageFileSender/>

    );
  }
}
export default App;